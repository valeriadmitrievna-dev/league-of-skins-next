export type ApiErrorCode = `ERR_${number}`;

export interface ApiError {
  code: string;
  message?: string;
  status?: number;
}
